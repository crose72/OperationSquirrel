#pragma once

#include <sigslot/signal.hpp>

