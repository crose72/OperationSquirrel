Terabee SDK v.1.1.3
c&p Terabee S.A.S. 2019

The content
1) Documentation - contains the full documentation for the SDK in the JavaDoc format.
2) EULA.txt - the distribution license, please ready carefully before starting to use this product.
3) Readme.txt - this file.
4) Terabee_SDK_Demo_App_{VERSION_NUMBER}.apk - a demo app showing how to use the SDK.
5) Terabee_SDK_{VERSION_NUMBER}.aar - Terabee SDK for Android in the AAR library format.
6) Terabee_SDK_Quck_Start_Guide.pdf - a guide outlining how to start using the SDK in your project in a few simple steps.

For additional support please contact Terabee at teraranger@terabee.com.


Release Notes

v1.1.3
- add SDK support for TeraRanger Evo Mini
- add Demo support for Evo Mini, also auto-detects
- updated QuickStart, Javadoc and Demo source files
- new aar and apk files

Note: "single range" mode support only (default)