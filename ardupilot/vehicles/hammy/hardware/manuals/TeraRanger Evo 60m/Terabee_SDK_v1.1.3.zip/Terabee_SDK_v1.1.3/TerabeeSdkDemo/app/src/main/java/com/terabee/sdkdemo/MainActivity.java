package com.terabee.sdkdemo;

import android.app.Dialog;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.terabee.sdk.TerabeeSdk;
import com.terabee.sdkdemo.databinding.ActivityMainBinding;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    private static final String[] SENSOR_TYPES = {
            TerabeeSdk.DeviceType.AUTO_DETECT.name(),
            TerabeeSdk.DeviceType.EVO_3M.name(),
            TerabeeSdk.DeviceType.EVO_60M.name(),
            TerabeeSdk.DeviceType.EVO_64PX.name(),
            TerabeeSdk.DeviceType.MULTI_FLEX.name(),
            TerabeeSdk.DeviceType.EVO_MINI.name(),
    };

    private static final String[] MULTIFLEX_SENSORS_LIST = {
            "Enable Sensor 1",
            "Enable Sensor 2",
            "Enable Sensor 3",
            "Enable Sensor 4",
            "Enable Sensor 5",
            "Enable Sensor 6",
            "Enable Sensor 7",
            "Enable Sensor 8"
    };

    private ActivityMainBinding mBinding;

    private TerabeeSdk.DeviceType mCurrentType = TerabeeSdk.DeviceType.AUTO_DETECT;

    private State mCurrentState = State.Disconnected;

    private TerabeeSdk.MultiflexConfiguration mMultiflexConfiguration = TerabeeSdk.MultiflexConfiguration.all();

    private final TerabeeSdk.DataSensorCallback mAllDataCallback = new TerabeeSdk.DataSensorCallback() {
        @Override
        public void onMatrixReceived(List<List<Integer>> list, int dataBandwidth, int dataSpeed) {
            updateMatrix(list, dataBandwidth, dataSpeed);
        }

        @Override
        public void onDistancesReceived(List<Integer> list, int dataBandwidth, int dataSpeed) {
            updateDistances(list, dataBandwidth, dataSpeed);
        }

        @Override
        public void onDistanceReceived(int distance, int dataBandwidth, int dataSpeed) {
            updateDistance(distance, dataBandwidth, dataSpeed);
        }

        @Override
        public void onReceivedData(byte[] data, int dataBandwidth, int dataSpeed) {
            // no need to implement
        }
    };

    private final TerabeeSdk.DataDistanceCallback mDataDistanceCallback = new TerabeeSdk.DataDistanceCallback() {
        @Override
        public void onDistanceReceived(int distance, int dataBandwidth, int dataSpeed) {
            updateDistance(distance, dataBandwidth, dataSpeed);
        }

        @Override
        public void onReceivedData(byte[] data, int dataBandwidth, int dataSpeed) {
            // no need to implement
        }
    };

    private final TerabeeSdk.DataMatrixCallback mDataMatrixCallback = new TerabeeSdk.DataMatrixCallback() {
        @Override
        public void onMatrixReceived(List<List<Integer>> list, int dataBandwidth, int dataSpeed) {
            updateMatrix(list, dataBandwidth, dataSpeed);
        }

        @Override
        public void onReceivedData(byte[] data, int dataBandwidth, int dataSpeed) {
            // no need to implement
        }
    };

    private final TerabeeSdk.DataDistancesCallback mDataDistancesCallback = new TerabeeSdk.DataDistancesCallback() {
        @Override
        public void onDistancesReceived(List<Integer> list, int dataBandwidth, int dataSpeed) {
            updateDistances(list, dataBandwidth, dataSpeed);
        }

        @Override
        public void onReceivedData(byte[] data, int dataBandwidth, int dataSpeed) {
            // no need to implement
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mBinding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        mCurrentType = TerabeeSdk.DeviceType.AUTO_DETECT;
        mBinding.configuration.setEnabled(true);

        // initialize UI
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, SENSOR_TYPES);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mBinding.sensorType.setAdapter(adapter);
        mBinding.sensorType.setSelection(0);
        mBinding.sensorType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                setCurrentType(((TextView) view).getText().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // no any action
            }
        });

        mBinding.connect.setOnClickListener(v -> connectToDevice());
        mBinding.disconnect.setOnClickListener(v -> disconnectDevice());
        mBinding.configuration.setOnClickListener(v -> showMultiflexConfigurationDialog());

        updateUiState();

        // init Terabee Sdk
        TerabeeSdk.getInstance().init(this);

        // set callback for receive data from sensors
        // can use single callback instead of callback for each sensor
        // this approach more convenient for connection with auto detect of sensor
        TerabeeSdk.getInstance().registerDataReceive(mAllDataCallback);

        // set callback for receive data from one pixel sensor
        // TerabeeSdk.getInstance().registerDataReceive(mDataDistanceCallback);

        // set callback for receive data from matrix sensor
        // TerabeeSdk.getInstance().registerDataReceive(mDataMatrixCallback);

        // set callback for receive data from multi flex sensro
        // TerabeeSdk.getInstance().registerDataReceive(mDataDistancesCallback);
    }

    @Override
    protected void onDestroy() {
        // release Terabee Sdk
        clearDataReceivers();
        TerabeeSdk.getInstance().dispose();
        super.onDestroy();
    }

    private void connectToDevice() {
        Thread connectThread = new Thread(() -> {
            try {
                setState(State.Connecting);

                Map<TerabeeSdk.DeviceType, TerabeeSdk.IConfiguration> configurations = new HashMap<>();
                configurations.put(TerabeeSdk.DeviceType.MULTI_FLEX, mMultiflexConfiguration);

                TerabeeSdk.getInstance().connect(new TerabeeSdk.IUsbConnect() {
                    @Override
                    public void connected(boolean success, TerabeeSdk.DeviceType deviceType) {
                        if (success) {
                            setState(State.Connected);
                            showShortToast("Connected sensor: " + deviceType.name());
                        } else {
                            setState(State.Disconnected);

                            if (deviceType != null) {
                                showShortToast("Unable connect to sensor: " + deviceType.name());
                            } else {
                                showShortToast("Unable connect to sensor");
                            }

                        }
                    }

                    @Override
                    public void disconnected() {
                        setState(State.Disconnected);
                    }

                    @Override
                    public void permission(boolean granted) {
                        // no need to implement
                        Log.d(TAG, "permission: " + granted);
                    }
                }, mCurrentType, configurations);
            } catch (Exception e) {
                Log.e(TAG, e.getMessage());
            }
        });

        connectThread.start();
    }

    private void disconnectDevice() {
        try {
            TerabeeSdk.getInstance().disconnect();
            setState(State.Disconnected);
        } catch (Exception e) {
            Log.e(TAG, e.getMessage());
        }
    }

    private void clearDataReceivers() {
        TerabeeSdk.getInstance().unregisterDataReceive(mAllDataCallback);

        // TerabeeSdk.getInstance().unregisterDataReceive(mDataDistanceCallback);
        // TerabeeSdk.getInstance().unregisterDataReceive(mDataMatrixCallback);
        // TerabeeSdk.getInstance().unregisterDataReceive(mDataDistancesCallback);
    }

    @Override
    public void finishAndRemoveTask() {
        super.finishAndRemoveTask();
    }

    private void setState(State value) {
        mCurrentState = value;
        updateUiState();
    }

    private void updateUiState() {
        runOnUiThread(() -> {
            switch (mCurrentState) {
                case Disconnected: {
                    mBinding.sensorType.setEnabled(true);
                    mBinding.connect.setEnabled(true);
                    mBinding.disconnect.setEnabled(false);
                    mBinding.data.setText("");
                    mBinding.dataBandwidth.setText("0");
                    mBinding.configuration.setEnabled(mCurrentType == TerabeeSdk.DeviceType.MULTI_FLEX || mCurrentType == TerabeeSdk.DeviceType.AUTO_DETECT);
                    break;
                }
                case Connecting: {
                    mBinding.sensorType.setEnabled(false);
                    mBinding.connect.setEnabled(false);
                    mBinding.disconnect.setEnabled(false);
                    mBinding.data.setText("");
                    mBinding.dataBandwidth.setText("0");
                    mBinding.configuration.setEnabled(false);
                    break;
                }
                case Connected: {
                    mBinding.sensorType.setEnabled(false);
                    mBinding.connect.setEnabled(false);
                    mBinding.disconnect.setEnabled(true);
                    mBinding.data.setText("");
                    mBinding.dataBandwidth.setText("0");
                    mBinding.configuration.setEnabled(false);
                    break;
                }
            }
        });
    }

    private void setCurrentType(String value) {
        mCurrentType = TerabeeSdk.DeviceType.valueOf(value);
        mBinding.configuration.setEnabled(mCurrentType == TerabeeSdk.DeviceType.MULTI_FLEX ||
                mCurrentType == TerabeeSdk.DeviceType.AUTO_DETECT);
    }

    private boolean[] mSelectedMultiflexSensors = null;

    private void showMultiflexConfigurationDialog() {
        mSelectedMultiflexSensors = new boolean[]{
                mMultiflexConfiguration.isSensor1Enable(),
                mMultiflexConfiguration.isSensor2Enable(),
                mMultiflexConfiguration.isSensor3Enable(),
                mMultiflexConfiguration.isSensor4Enable(),
                mMultiflexConfiguration.isSensor5Enable(),
                mMultiflexConfiguration.isSensor6Enable(),
                mMultiflexConfiguration.isSensor7Enable(),
                mMultiflexConfiguration.isSensor8Enable()
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Multiflex configuration");
        builder.setMultiChoiceItems(MULTIFLEX_SENSORS_LIST, mSelectedMultiflexSensors,
                (dialog, selectedItemId, isSelected) -> mSelectedMultiflexSensors[selectedItemId] = isSelected)
                .setPositiveButton("Done", (dialog, id) -> {
                    // apply changes
                    mMultiflexConfiguration = TerabeeSdk.MultiflexConfiguration.custom(
                            mSelectedMultiflexSensors[0],
                            mSelectedMultiflexSensors[1],
                            mSelectedMultiflexSensors[2],
                            mSelectedMultiflexSensors[3],
                            mSelectedMultiflexSensors[4],
                            mSelectedMultiflexSensors[5],
                            mSelectedMultiflexSensors[6],
                            mSelectedMultiflexSensors[7]
                    );
                })
                .setNegativeButton("Cancel", (dialog, id) -> {
                    // not apply changes
                });
        Dialog dialog = builder.create();
        dialog.show();
    }

    private void updateMatrix(List<List<Integer>> list, int dataBandwidth, int dataSpeed) {
        runOnUiThread(() -> {
            if (mCurrentState == State.Connected) {
                mBinding.dataBandwidth.setText("Bandwidth: " + dataBandwidth);

                if (list != null) {
                    String matrix = "Matrix: \n";

                    for (int i = 0; i < list.size(); i++) {
                        for (int j = 0; j < list.get(i).size(); j++) {
                            matrix += String.valueOf(list.get(i).get(j)) + ", ";
                        }

                        matrix += "\n";
                    }

                    mBinding.data.setText(matrix);
                }
            }
        });
    }

    private void updateDistance(int distance, int dataBandwidth, int dataSpeed) {
        runOnUiThread(() -> {
            if (mCurrentState == State.Connected) {
                mBinding.dataBandwidth.setText("Bandwidth: " + dataBandwidth);
                mBinding.data.setText("Distance: " + distance);
            }
        });
    }

    private void updateDistances(List<Integer> list, int dataBandwidth, int dataSpeed) {
        runOnUiThread(() -> {
            if (mCurrentState == State.Connected) {
                mBinding.dataBandwidth.setText("Bandwidth: " + dataBandwidth);

                if (list != null) {
                    Log.d(TAG, "onDistancesReceived, size: " + list.size());
                    Log.d(TAG, "onDistancesReceived, list: " + list.toString());

                    String distances = "Distances: \n";

                    for (int i = 0; i < list.size(); i++) {
                        distances += "Sensor " + String.valueOf(i + 1);
                        distances += ": " + String.valueOf(list.get(i));
                        distances += "\n";
                    }

                    mBinding.data.setText(distances);
                }
            }
        });
    }

    private void showShortToast(String message) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }

    private enum State {
        Disconnected,
        Connecting,
        Connected,
    }
}
